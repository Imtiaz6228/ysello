import { ApiError } from "../middleware/error-handler.js";
export const SHOP2TOPUP_DEFAULT_BASE_URL = "https://shop2topup.com/api/endpoints/v1";
function isRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function providerMessage(body, status) {
    if (isRecord(body) && isRecord(body.error)) {
        const code = typeof body.error.code === "string" ? body.error.code : null;
        const message = typeof body.error.message === "string" ? body.error.message : null;
        return {
            code: code || `SHOP2TOPUP_HTTP_${status}`,
            message: message || code || `SHOP2TOPUP returned HTTP ${status}.`,
            details: body.error.details,
        };
    }
    return {
        code: `SHOP2TOPUP_HTTP_${status}`,
        message: `SHOP2TOPUP returned HTTP ${status}.`,
        details: undefined,
    };
}
export class Shop2TopupClient {
    apiKey;
    baseUrl;
    timeoutMs;
    fetchImplementation;
    constructor(options) {
        this.apiKey = options.apiKey.trim();
        this.baseUrl = (options.baseUrl ?? SHOP2TOPUP_DEFAULT_BASE_URL).replace(/\/+$/, "");
        this.timeoutMs = options.timeoutMs ?? 15_000;
        this.fetchImplementation = options.fetchImplementation ?? fetch;
    }
    async request(pathname, init = {}, retry429 = true) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
        try {
            const headers = new Headers(init.headers);
            headers.set("Accept", "application/json");
            headers.set("Authorization", `Bearer ${this.apiKey}`);
            if (init.body)
                headers.set("Content-Type", "application/json");
            const response = await this.fetchImplementation(`${this.baseUrl}${pathname}`, {
                ...init,
                signal: controller.signal,
                headers,
            });
            let body = null;
            try {
                body = await response.json();
            }
            catch {
                body = null;
            }
            if (response.status === 429 && retry429) {
                const retryAfter = Math.max(1, Math.min(60, Number(response.headers.get("retry-after") || 5)));
                await new Promise((resolve) => setTimeout(resolve, retryAfter * 1_000));
                return this.request(pathname, init, false);
            }
            const failedEnvelope = body;
            if (!response.ok || failedEnvelope?.success === false) {
                const provider = providerMessage(body, response.status);
                throw new ApiError(response.status >= 400 ? response.status : 502, provider.message, provider.code, provider.details);
            }
            return body;
        }
        catch (error) {
            if (error instanceof ApiError)
                throw error;
            if (error instanceof Error && error.name === "AbortError") {
                throw new ApiError(504, "SHOP2TOPUP did not answer before the server timeout.", "SHOP2TOPUP_TIMEOUT");
            }
            throw new ApiError(502, "SHOP2TOPUP could not be reached from the API server.", "SHOP2TOPUP_UNAVAILABLE");
        }
        finally {
            clearTimeout(timeout);
        }
    }
    async getAccount() {
        const result = await this.request("/account");
        return result.account;
    }
    async listBigCategories(forUi = true) {
        const result = await this.request(`/catalog/big-categories?for_ui=${forUi ? "true" : "false"}`);
        return result.big_categories ?? [];
    }
    async listCategories(bigCategoryId, forUi = true) {
        const params = new URLSearchParams({ for_ui: forUi ? "true" : "false" });
        if (bigCategoryId)
            params.set("bigCategoryId", String(bigCategoryId));
        const result = await this.request(`/catalog/categories?${params}`);
        return result.categories ?? [];
    }
    async listSubcategories(categoryId) {
        const suffix = categoryId ? `?categoryId=${categoryId}` : "";
        const result = await this.request(`/catalog/subcategories${suffix}`);
        return result.subcategories ?? [];
    }
    async getPrice(itemId) {
        const result = await this.request(`/catalog/subcategory/${itemId}/price`);
        return result.price;
    }
    async getRequirements(categoryId) {
        const result = await this.request(`/catalog/category/${categoryId}/requirements`);
        return result.requirements ?? [];
    }
    async validatePlayer(subCategoryId, requirements) {
        return this.request("/player/validate", {
            method: "POST",
            body: JSON.stringify({ sub_category_id: subCategoryId, ...requirements }),
        });
    }
    async createOrder(input) {
        const result = await this.request("/orders/create", {
            method: "POST",
            body: JSON.stringify({
                order_id: input.orderId,
                sub_category_id: input.subCategoryId,
                quantity: input.quantity,
                requirements: input.requirements,
                ...(input.expectedUnitPrice
                    ? { expected_unit_price: input.expectedUnitPrice }
                    : {}),
            }),
        });
        return result.order;
    }
    async getOrder(orderId) {
        const result = await this.request(`/orders/${encodeURIComponent(orderId)}`);
        return result.order;
    }
}
